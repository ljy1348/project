import React from 'react'

function PaymentResult() {
  return (
    <div>결제 성공!</div>
  )
}

export default PaymentResult