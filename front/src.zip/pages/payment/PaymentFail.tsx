import React from 'react'

function PaymentFail() {



  return (
    <div>a</div>
  )
}

export default PaymentFail