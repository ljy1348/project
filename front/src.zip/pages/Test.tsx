import React from 'react'

function Test() {
  return (
    <div>{"ㄹㄷㄹㄷㄹ\nㄹㄷㄹㄷㄹㄷ\nㄷㄹㄷㄹㄷㄹㄷㄹ\nㄷㄹㄷㄹㄷㄹㄷㄹㄷㄹㄷㄹ"}</div>
  )
}

export default Test