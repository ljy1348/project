import React from 'react'

function AdminQuestion() {
  return (
    <div>AdminQuestion</div>
  )
}

export default AdminQuestion