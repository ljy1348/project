import React from 'react'

function AdminFaq() {
  return (
    <div>AdminFaq</div>
  )
}

export default AdminFaq