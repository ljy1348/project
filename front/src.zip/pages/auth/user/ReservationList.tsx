import React from 'react'

function ReservationList() {
  return (
    <div>ReservationList</div>
  )
}

export default ReservationList