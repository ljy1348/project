export default interface INotice {
    noticeId?: any | null,
    noticeWriter: string,
    noticeContent: string,
    noticeTitle: string,
    memberid: string,
    insertTime: string
}