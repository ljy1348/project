export default interface IRdata {
    reservenum: string | number,
    price:string | number
}