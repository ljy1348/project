import INonmemberinfo from "../INonmemberinfo";

export default interface ICount {
    adult:boolean | any,
    name:string
    
}