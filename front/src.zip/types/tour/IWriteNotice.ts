// IWriteNotice.ts
export default interface IWriteNotice {
    noticeId?: any | null,
    noticeTitle: string,
    noticeContent: string
    memberId:string
}