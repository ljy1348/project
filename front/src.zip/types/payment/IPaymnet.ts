export default interface IPaymnet {
    
}