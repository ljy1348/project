export default interface INonmemberinfo {
    userNumber?: any | null,
    userName: string,
    userSex: string,
    userCountry: string,
    userDate:  string,
    userPhone: string,
    userEmail: string,    
}