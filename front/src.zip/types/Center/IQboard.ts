// 1:1 문의
export default interface IQboard {
  titleId?: any | null;
  title: string;
  content: string;
  answerYn: string;
  memberId: string;
  insertTime: string;
  respondent: string,
  paraentBid: number,
  titleCodeNumber: number,

    // updateTime: string,
  // deleteTime: string,
  // deleteYn: string,
}
