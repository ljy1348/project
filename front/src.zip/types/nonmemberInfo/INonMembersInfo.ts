export default interface INonMemberInfo {

// USER_NUMBER
// USER_NAME
// USER_SEX
// USER_COUNTRY
// USER_DATE
// USER_PHONE
// USER_EMAIL

   userNumber ?: any | null,
   userName : string,
   userSex : string,
   userCountry: string,
   userDate : Date | string,
   userPhone : string,
   userEmail : string

}