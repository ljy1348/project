package com.example.back.model.entity.auth;

/**
 * packageName : com.example.simpledms.repository.auth
 * fileName : ERole
 * author : GGG
 * date : 2023-11-14
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * —————————————————————————————
 * 2023-11-14         GGG          최초 생성
 */
public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}
